##################################################################################################################################################################################################
##################################################################################################################################################################################################
##################################################################################################################################################################################################

function Ent�te ($ENTETE)
{
clear
Write-Host ""
Write-Host "     __  __                 _                 " -ForegroundColor Blue -NoNewline;Write-Host " ____                           "-ForegroundColor White -NoNewline;Write-Host " _____  ___   ___   ___  " -ForegroundColor Red
Write-Host "    |  \/  | ___  _ __  ___(_) ___ _   _ _ __ " -ForegroundColor Blue -NoNewline;Write-Host "|  _ \ _ __ ___  _ __  _ __ ___ "-ForegroundColor White -NoNewline;Write-Host "|___ / / _ \ / _ \ / _ \ " -ForegroundColor Red
Write-Host "    | |\/| |/ _ \| '_ \/ __| |/ _ \ | | | '__|" -ForegroundColor Blue -NoNewline;Write-Host "| |_) | '__/ _ \| '_ \| '__/ _ \"-ForegroundColor White -NoNewline;Write-Host "  |_ \| | | | | | | | | |" -ForegroundColor Red
Write-Host "    | |  | | (_) | | | \__ \ |  __/ |_| | |   " -ForegroundColor Blue -NoNewline;Write-Host "|  __/| | | (_) | |_) | | |  __/"-ForegroundColor White -NoNewline;Write-Host " ___) | |_| | |_| | |_| |" -ForegroundColor Red
Write-Host "    |_|  |_|\___/|_| |_|___/_|\___|\__,_|_|   " -ForegroundColor Blue -NoNewline;Write-Host "|_|   |_|  \___/| .__/|_|  \___|"-ForegroundColor White -NoNewline;Write-Host "|____/ \___/ \___/ \___/ " -ForegroundColor Red
Write-Host "                                              " -ForegroundColor Blue -NoNewline;Write-Host "                |_|             "-ForegroundColor White -NoNewline;Write-Host "                         " -ForegroundColor Red -NoNewline;Write-Host "By FR" -ForegroundColor White
Write-Host ""
}
Ent�te

##################################################################################################################################################################################################
##################################################################################################################################################################################################
##################################################################################################################################################################################################

$DATE = Get-Date -Format "yyyyMMdd"

##################################################################################################################################################################################################
##################################################################################################################################################################################################
##################################################################################################################################################################################################

Write-Host " Bienvenue dans l'outil de purge et de compression Monsieur Propre 3000 ! "
Write-Host " ------------------------------------------------------------------------"
Write-Host ""
Write-Host ""
$EMPLACEMENT = Read-Host " Dans quel r�pertoire se situe le fichier ? "
Write-Host ""
$FICHIER = Read-Host " Quel est le fichier � compresser ? "
Write-Host ""
$EMPLACEMENTTEMPORAIRE = Read-Host " Dans quel r�pertoire temporaire voulez-vous mettre votre fichier ? (/tmp par defaut) "
Write-Host ""
if ($EMPLACEMENTTEMPORAIRE -eq "")
        {
   $EMPLACEMENTTEMPORAIRE = "/tmp" 
        }

##################################################################################################################################################################################################
##################################################################################################################################################################################################
##################################################################################################################################################################################################

function Menu ($PURGE)
{
$MENUPURGE = Read-Host " Voulez-vous purger le fichier une fois celui-ci compress� ? ('oui' par defaut) "

if ($MENUPURGE -eq "")
 {
   $MENUPURGE = "oui" 
 }

Write-Host ""

    switch ($MENUPURGE)
    {
        oui           {$COMMANDE="cp -p $EMPLACEMENT/$FICHIER $EMPLACEMENTTEMPORAIRE/$FICHIER.$DATE && >$EMPLACEMENT/$FICHIER && gzip -9 $EMPLACEMENTTEMPORAIRE/$FICHIER.$DATE && mv $EMPLACEMENTTEMPORAIRE/$FICHIER.$DATE.gz $EMPLACEMENT/ && df -h $EMPLACEMENT"
                      }
        
        non           {$COMMANDE="cp -p $EMPLACEMENT/$FICHIER $EMPLACEMENTTEMPORAIRE/$FICHIER.$DATE && gzip -9 $EMPLACEMENTTEMPORAIRE/$FICHIER.$DATE && mv $EMPLACEMENTTEMPORAIRE/$FICHIER.$DATE.gz $EMPLACEMENT/ df -h $EMPLACEMENT"
                      }
        
        default       {Write-Host " Mauvais choix, veuillez r�essayer" -ForegroundColor "Red"
                      }
    }

    if ($MENUPURGE -eq "oui" -or $MENUPURGE -eq "non")
     
           {
      
Ent�te
      
      Write-Host " Rappel des informations saisies : " -ForegroundColor "Green"
      Write-Host " ---------------------------------"
      Write-Host ""
      Write-Host ""
      Write-Host " Emplacement du fichier : $EMPLACEMENT"
      Write-Host " Fichier � compresser   : $FICHIER"
      Write-Host " Emplacement temporaire : $EMPLACEMENTTEMPORAIRE"
      Write-Host " Purge du fichier       : $MENUPURGE"
      Write-Host ""
      Write-Host ""
      Write-Host " Commande � utiliser (copy to clipboard !) : " -ForegroundColor "Green"
      Write-Host " -------------------------------------------"
      Write-Host ""
      Write-Host " $COMMANDE"
      Set-Clipboard -Value $COMMANDE
      Write-Host ""
      Write-Host ""
      Write-Host " Message de cl�ture Service Manager : " -ForegroundColor "Green"
      Write-Host " ------------------------------------"
      Write-Host ""
      Write-Host " Compression du fichier ""$FICHIER"" dans le r�pertoire ""$EMPLACEMENT"""
      Write-Host " Plus d'alerte en supervision"
      Write-Host ""
            }
    else
    {
     Menu
    }
}
Menu
##################################################################################################################################################################################################
##################################################################################################################################################################################################
##################################################################################################################################################################################################